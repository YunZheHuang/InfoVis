var width = 600;
var height = 400;

var margin = {top:40, right: 40, bottom: 50, left: 100};

d3.json('./years.json').then(years => {

  var container = d3.create('svg')
       .attr('width', width + margin.left + margin.right)
       .attr('height', height + margin.top + margin.bottom);

con ageDomain = unique(years.map(row => row.age));
var peopleDomain = [0, d3.max(years, row => row.population)];

var age = ["0--8", "9--17", "18--20", "21--23", "24--26", "27--29", "30--38", "39--47", "48+"]

var xScale = d3.scalePoint()
            .range([0, width])
            .domain(age)
            .padding(0.2);

})


