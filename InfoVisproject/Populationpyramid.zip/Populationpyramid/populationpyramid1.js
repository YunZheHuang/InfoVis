

var margin = {top: 0, right: 30, bottom: 50, left: 60},
    width = 800 - margin.left - margin.right,
    height = 800 - margin.top - margin.bottom;



// append the svg object to the body of the page
var svg = d3.select("#main")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform",
          "translate(" + margin.left + "," + margin.top + ")");

function dataProcessor(d) {
    return {
        year: +d.year,
        gender: d.gender,
        age: +d.age,
        population: +d.population

    };
}

d3.csv('years.csv', dataProcessor).then(function(data) {


var age = ["0--8", "9--17", "18--20", "21--23", "24--26", "27--29", "30--38", "39--47", "48+"]

var xScale = d3.scalePoint()
            .range([0, width])
            .domain(age)
            .padding(0.2);


svg.append("g")
   .attr("transform", "translate(0," + height + ")")
   .call(d3.axisBottom(xScale))
   .selectAll("text")
   .attr("transform", "translate(-10,0)rotate(-45")
   .style("text-anchor", "end");


var populationMax = d3.max(data, function(d) {
       return +d.population
});

var populationMin = d3.min(data, function(d) {
      return +d.population
});

var yScale = d3.scaleLinear()
               .domain([populationMin, populationMax])
               .range([height, 0]);

svg.append("g")
   .call(d3.axisLeft(yScale));




svg.selectAll('text')
   .style("font-family", "sans-serif")


title = svg.append("text")
       .attr("transform", "translate(" +((width + margin.left + margin.right)/2) + "," + 20 + ")")
       .style("text-anchor", "middle")
       .style("font-weight", 900)
       .text("Census Age Group and missing population by gender");

svg.append("text")             
      .attr("transform", "rotate(-90)")
      .attr("y", 0 - margin.left)
      .attr("x", 0 - (height / 2))
      .attr("dy", "1em")
      .style("text-anchor", "middle")
      .style("font-weight", 900)
      .text("population");

svg.append("text")
   .attr("transform", "translate(" + (width/2) + "," + (height + margin.top +40) + ")")
   .style("text-anchor", "middle")
   .style("font-weight", 900)
   .text("Age Group");




dataset = ["Male", "Female"]
var color_hash = {  0 : ["Male", "blue"],
                    1 : ["Female", "pink"]}

var legend = svg.append("g")
            .attr("class", "legend")
            .attr("x", width - 65)
            .attr("y", 25)
            .attr("height", 100)
            .attr("width", 100);

legend.selectAll('g').data(dataset)
      .enter()
      .append('g')
      .each(function(d, i) {
        var g = d3.select(this);
        g.append("rect")
         .attr("x", width - 65)
         .attr("y", i*25)
         .attr("width", 10)
         .attr("height", 10)
         .style("fill", color_hash[String(i)][1]);
        g.append("text")
         .attr("x", width - 50)
         .attr("y", i * 25 + 8)
         .attr("height", 30)
         .attr("width", 100)
         .style("fill", color_hash[String(i)[1]])
         .text(color_hash[String(i)][0]);

state = ({year: 2002, gender: Female})

function isYearAndGender (data, year, gender) {
  return data.year === year && data.gender === gender;
}

filteredData = data.filter(data => isYearAndGender(data, state.year, state.gender));

bars = svg.selectAll('.bar').data(filteredData);

enterbars = bars.enter()
            .enter()
            .append('rect')
            .attr('class', 'bar')
            .attr('x', (d) => xScale(d.age))
            .attr('y', (d) => yScale(d.population))
            .attr('width', xScale.bandwidth())
            .attr('height', (d) => height - yScale(d.population))
            .attr('fill', (d) => color_hash[String(i)][1]);




});





	


});



                   






